package com.app.services;


import java.util.List;
import java.util.Optional;

import com.app.pojos.JobDetail;


public interface IJobDetailService {

	JobDetail addJobDetailsToDB(JobDetail transientPOJO);

	JobDetail editJobtDetailsToDB(int jobid, JobDetail detachedPOJO);

	String delJobByIdToDB(int id);

	Optional<JobDetail> getJobDetailsFromDB(String jobName);

	List<JobDetail> getAllStudents();
	

}
