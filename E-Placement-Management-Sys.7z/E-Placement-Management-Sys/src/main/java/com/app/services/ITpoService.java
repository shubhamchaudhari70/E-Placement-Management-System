package com.app.services;

import java.util.List;
import java.util.Optional;

import com.app.pojos.Companies;
import com.app.pojos.Message;
import com.app.pojos.Tpo;

public interface ITpoService {
	//get all companies
	List<Companies> fetchCompanyList();
	// add(post) company details by name
	Companies addCompanyToDB(Companies companies);
	// get company details by id
	Optional<Companies> fetchCompanyById(int id);
	// del company details by id
	String delCompanyById(int id);
	String fetchTpoByEmailAndPassword(String email, String password);
	Tpo registerTpo(Tpo c);
	Message postMessageToDB(Message msg);
	Optional<Message> fetchMessageByNameFromDB(String msg);
	Message editMessageDetailsToDB(int msgid, Message o);
	;
}