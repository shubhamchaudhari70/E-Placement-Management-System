package com.app.services;



import com.app.pojos.CompanyManager;


public interface ICompanyManagerService {

	String fetchStudentByEmailAndPassword(String emaiI, String password);	   //for login
	CompanyManager registerCompany(CompanyManager m);							//for register

}
