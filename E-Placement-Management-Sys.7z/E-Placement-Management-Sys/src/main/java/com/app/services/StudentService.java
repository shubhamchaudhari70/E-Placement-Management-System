package com.app.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_excs.StudentNotFoundException;
import com.app.dao.IAppliedJob;
import com.app.dao.IStudentdao;
import com.app.pojos.AppliedJob;
import com.app.pojos.JobDetail;
import com.app.pojos.Message;
import com.app.pojos.Student;

@Service
@Transactional
public class StudentService implements IStudentService {
	
	@Autowired
	private IStudentdao dao;
	@Autowired
	private IAppliedJob dao1;
	
	
	
	
	@Override
	public List<Student> getAllStudents() {
		System.out.println("dao imple class " + dao.getClass().getName());
		return dao.findAll();
	}
	

	@Override
	public  Optional<Student> getStudentDetails(String sName) {
		// TODO Auto-generated method stub
		return dao.findByName(sName);
	}

	
	@Override
	public Student addStudentDetails(Student transientPOJO) {
		// TODO Auto-generated method stub
		return dao.save(transientPOJO);								//transientPOJO aslyane direct data save , detached ast tr khali method dili ah tas karav lagl ast
	}
	

	@Override
	public Student updateStudentDetails(int studentId, Student oldDetails) {					//p1--- means--- detachedPOJO
		Optional<Student> checkPresence = dao.findById(studentId);
		if (checkPresence.isPresent()) {
			// checkpresence.get() : PERSISTENT  POJO                here dirty checking happen,so we change the state of persistent pojo
			// oldDetails: detached POJO : contains the updates sent by student,    no dirty checking by pojo------>to DB , means row by row checking
			// change state of persistent POJO
			Student updatedDetails = checkPresence.get();					
			updatedDetails.setAddress(oldDetails.getAddress());		//eth oldDetails means detached ah na so detached pojo mde he update hoil sarv data
			updatedDetails.setName(oldDetails.getName());
			updatedDetails.setEmail(oldDetails.getEmail());
			updatedDetails.setPassword(oldDetails.getPassword());
			updatedDetails.setDob(oldDetails.getDob());
			updatedDetails.setContact(oldDetails.getContact());
			updatedDetails.setGender(oldDetails.getGender());
			updatedDetails.setHobbies(oldDetails.getHobbies());
			updatedDetails.setDegree_per(oldDetails.getDegree_per());
			updatedDetails.setProject_details(oldDetails.getProject_details());
			
			 
			return updatedDetails;
	}
		//in case of no student found : throw custom exception
				throw new StudentNotFoundException("Invalid Student");

}


	@Override
	public Student delStudentById(int id) {
		dao.deleteById(id);						//dao method mean jpa chi, yala jr id null milala tr illegalargument throw hence we use try catch block, and return string to we know deleted or not 
		return null;
				
	}


	@Override
	public Student fetchCandidateByEmail(String tempEmail) {
		
		return dao.findByEmail(tempEmail);
	}


	@Override
	public String fetchStudentByEmailAndPassword(String emaiI, String password) {					//for login
	return	dao.findByEmailAndPassword(emaiI, password);
		
	}


	
	@Override
	public Student registerStudent(Student s) {																				//for register
																								//for register
			 Student st=new Student();
			 st.setName(s.getName());
			 st.setEmail(s.getEmail());
			 st.setPassword(s.getPassword());
			 
			return dao.save(st);														//dao i.e IStudentdao extends jpaRepo 
		}



	@Override
	public AppliedJob applyJobbyStud(AppliedJob o) {			//store data in applied job table, and this data we will fetch in companymnager
		AppliedJob n=new AppliedJob();
		n.setConfirmEmail(o.getConfirmEmail());
		n.setConfirmName(o.getConfirmName());
		n.setPreferlocation(o.getPreferlocation());
		return dao1.save(n);																//dao 1  i.e IAppliedao extends jpaRepo 
	}


	@Override
	public AppliedJob delAppliedJobById(int id) {
		dao1.deleteById(id);
		return null;
	}


	@Override
	public List<AppliedJob> getAllAppliedStudentFromDB() {
		System.out.println("dao imple class " + dao.getClass().getName());
		return dao1.findAll();
		
	}


	
}
	
	
	
