package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_excs.JobNotFoundException;
import com.app.dao.IJobDetaildao;
import com.app.pojos.JobDetail;

@Service
public class JobDetailService implements IJobDetailService {

	@Autowired
	private IJobDetaildao dao;
	@Override
	public JobDetail addJobDetailsToDB(JobDetail transientPOJO) {
		return dao.save(transientPOJO);
	}

	
	@Override
	public JobDetail editJobtDetailsToDB(int jobid, JobDetail oldDetails) {
		Optional<JobDetail> checkPresence = dao.findById(jobid);
		if (checkPresence .isPresent()) {
			JobDetail updatedDetails = checkPresence.get();					
			updatedDetails.setCname(oldDetails.getCname());
			updatedDetails.setDesignation(oldDetails.getDesignation());
			updatedDetails.setExperience(oldDetails.getExperience());
			updatedDetails.setLocation(oldDetails.getLocation());
			updatedDetails.setResponsibility(oldDetails.getResponsibility());
			updatedDetails.setSalary(oldDetails.getSalary());
			updatedDetails.setSkill(oldDetails.getSkill());
			updatedDetails.setTechnology(oldDetails.getTechnology());
			updatedDetails.setBeginDate(oldDetails.getBeginDate());
			updatedDetails.setEndDate(oldDetails.getEndDate());

			return updatedDetails;
			
		}

		 throw new JobNotFoundException("Invalid job id");
	}
	
	

	@Override
	public String delJobByIdToDB(int id) {
		String result;
		try {
			dao.deleteById(id);					//dao method mean jpa chi, yala jr id null milala tr illegalargument throw hence we use try catch block, and return string to we know deleted or not 
			result ="Company Successfully Deleted..";
		} catch (Exception e) {
			result ="Company Not Deleted..";
		}
		return result;
	}

	
	@Override
	public Optional<JobDetail> getJobDetailsFromDB(String jobName) {
		return dao.findByDesignation(jobName);
		
	}
	

	@Override
	public List<JobDetail> getAllStudents() {						//manager can view itself list of all job, also student can see
		System.out.println("dao imple class " + dao.getClass().getName());
		return dao.findAll();
	}
	

}
