package com.app.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.app.dao.ICompanydao;
import com.app.pojos.CompanyManager;


@Service
@Transactional
public class CompanyManagerService implements ICompanyManagerService {
	
@Autowired
private ICompanydao dao;



	@Override
	public String fetchStudentByEmailAndPassword(String emaiI, String password) {				//for login
				return dao.findByEmailAndPassword(emaiI, password);
	}

	@Override
	public CompanyManager registerCompany(CompanyManager o) {								//for register
		 CompanyManager n=new CompanyManager();
		 n.setId(o.getId());
		 n.setName(o.getName());
		 n.setCname(o.getCname());
		 n.setEmail(o.getEmail());
		 n.setPassword(o.getPassword());
		 n.setContact(o.getContact());
		return dao.save(n);
	
	}

	
	
	
	
	
	
}
