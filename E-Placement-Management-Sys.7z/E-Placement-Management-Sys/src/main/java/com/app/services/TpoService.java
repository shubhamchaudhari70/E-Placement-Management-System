package com.app.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.custom_excs.JobNotFoundException;
import com.app.dao.IMessagedao;
import com.app.dao.ITpoValidationdao;
import com.app.dao.ITpodao;
import com.app.pojos.Companies;
import com.app.pojos.JobDetail;
import com.app.pojos.Message;
import com.app.pojos.Tpo;

@Service
public class TpoService implements ITpoService {
	@Autowired							//dependency injection...ITpodao inject here to use there functionality
	private ITpodao dao;
	@Autowired
	private ITpoValidationdao dao1;
	@Autowired
	private IMessagedao dao2;
	
	
	@Override
	public String fetchTpoByEmailAndPassword(String email, String password) {
		return dao1.findByEmailAndPassword(email, password); 											//for login	//fetch from DB using dao interface via JPA query , becz dao implement jPA class
	}
	

	@Override																											
	public Tpo registerTpo(Tpo c) {																								//for register
		 Tpo s=new Tpo();
		 s.setId(c.getId());
		 s.setName(c.getName());
		 s.setEmail(c.getEmail());
		 s.setPassword(c.getPassword());
		 s.setContact(c.getContact());
		return dao1.save(s);
	}
	
		
	
	
	@Override
	public List<Companies>fetchCompanyList(){	//controller mdun call hoil hi ,becz controller mde pn apn Tposervice inject kelay
		return dao.findAll();			//jpa chi method ah findall() ti dao through call keli dao here injected by DI
	}
	
	@Override
	public Companies addCompanyToDB(Companies companies) {
		return dao.save(companies);								//save() is a repository method i.e dao method ,1st step- incoming data save in DB nd 
																					//2nd step- return that response to itself companies
	}
	@Override
	public Optional<Companies> fetchCompanyById(int id) {           //return type optional means if data found then give  else give blank but not give error
		return dao.findById(id);						//dao method mean jpa chi, in pojo apn je column as a declare id ti method yeil 
		
	}
	
	@Override
	public String delCompanyById(int id) {           //return type optional means if data found then give  else give blank but not give error
		String result;
		try {
			dao.deleteById(id);						//dao method mean jpa chi, yala jr id null milala tr illegalargument throw hence we use try catch block, and return string to we know deleted or not 
			result ="Company Successfully Deleted..";
		} catch (Exception e) {
			result ="Company Not Deleted..";
		}
		return result;
		
	}

/*----------------------------------------------------------------------BL for message service post and get-------------------------------------------------------------------------------------------------------------------------------------------*/
	@Override
	public Message postMessageToDB(Message msg) {				//post message to student means 1st store in Db then we call get message in student
				 return dao2.save(msg);
	}


	@Override
	public Optional<Message> fetchMessageByNameFromDB(String msg) {
		return dao2.findByTpomsg(msg);
		
	}
	
	
	@Override
	public Message editMessageDetailsToDB(int msgid, Message o) {
		Optional<Message> checkPresence = dao2.findById(msgid);
		if (checkPresence.isPresent()) {
			System.out.println(checkPresence);
			Message updatedDetails = checkPresence.get();					
			updatedDetails.setTpomsg(o.getTpomsg());
			return updatedDetails;
	}
		 throw new JobNotFoundException("Invalid job id");
	}
	
																						
	
}
