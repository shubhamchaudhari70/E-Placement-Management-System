package com.app.services;

import java.util.List;
import java.util.Optional;

import com.app.pojos.AppliedJob;
import com.app.pojos.JobDetail;
import com.app.pojos.Message;
import com.app.pojos.Student;

public interface IStudentService {
	
	//get all students
	List<Student>getAllStudents();
	// get students details by name
	Optional<Student> getStudentDetails(String sName);
	//add new student details
	Student addStudentDetails(Student transientPOJO);
	// update existing students details
	Student updateStudentDetails(int studentId, Student detachedPOJO);
	Student delStudentById(int id);
	Student fetchCandidateByEmail(String tempEmail);
	String fetchStudentByEmailAndPassword(String emaiI, String password);				//login
	Student registerStudent(Student s);																				//register
	AppliedJob applyJobbyStud(AppliedJob aj);
	AppliedJob delAppliedJobById(int id);
	List<AppliedJob> getAllAppliedStudentFromDB();


}
