package com.app.pojos;

public enum Branch {
MECHANICAL,ELECTRICAL,COMPUTER,ELECTRONIC,IT,CIVIL
}
