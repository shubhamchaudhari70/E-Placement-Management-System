package com.app.pojos;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.springframework.format.annotation.DateTimeFormat;




@Entity														//Jpa will create table for Companies
public class Companies {

	@Id															//primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "company_id")
	private int id;
	@Column(length = 30,unique = true)
	private String cname;
	@Column
	private String criteria;
	@Column(length = 30,unique = true)
	private String email;
	@Column
	private String contact;
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate beginDate;		//for arrange drive date
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate endDate;			//for closing drive date
	
	@ManyToMany(cascade = {CascadeType.PERSIST,CascadeType.MERGE})  //mandatory : if not supplied hibernate throws MappingExc.
	@JoinTable(name = "applied_students",
	joinColumns = @JoinColumn(name="cname"),
	inverseJoinColumns = @JoinColumn(name="student_id"))
	private Set<Student> students=new HashSet<>(); 							//"students" property apn tikde student mde takli mapped by mhnun
	//companies  have hash set of student 
	//parameterless constructor
	
	public Companies() {
		super();
	}
	
	//Parameterized constructor
		public Companies(int id, String cname, String criteria, String email, String contact, LocalDate beginDate, LocalDate endDate, Set<Student> students) {
		super();
		this.id = id;
		this.cname = cname;
		this.criteria = criteria;
		this.email = email;
		this.contact = contact;
		this.beginDate = beginDate;
		this.endDate = endDate;
		this.students = students;
	}
	
	//Getter setters
		public int getId() {
			return id;
		}

	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	

	public LocalDate getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	
	
	
	
	

	//add helper methods : to add student in this company
		public void addStudent(Student s)
		{
			students.add(s);													//jya pn comany la student ne apply kel te eth (this) add kara 
			s.getAppliedCompanies().add(this);					//and that company added in students record													
		}
		//remove a student from this company
		public void removeStudent(Student s)														
		{
			students.remove(s);
			s.getAppliedCompanies().add(null);                         //add(null) karun baghne
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((cname == null) ? 0 : cname.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Companies other = (Companies) obj;
			if (cname == null) {
				if (other.cname != null)
					return false;
			} else if (!cname.equals(other.cname))
				return false;
			return true;
		}

	@Override
	public String toString() {
		return "Companies [id=" + id + ", cname=" + cname + ", criteria=" + criteria + ", email=" + email + ", contact="
				+ contact + ", beginDate=" + beginDate + ", endDate=" + endDate + ", students=" + students + "]";
	}

	
	
	
	
}
