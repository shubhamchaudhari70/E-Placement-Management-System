package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AppliedJob {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Integer Id;
	@Column(length = 50 )							//,nullable = false
	private String confirmName;
	@Column(length = 50 )							//,nullable = false
	private String confirmEmail;
	@Column(length = 50 )							//,nullable = false
	private String preferlocation;
	public AppliedJob() {
		super();
	}
	public AppliedJob(Integer id, String confirmName, String confirmEmail, String preferlocation) {
		super();
		Id = id;
		this.confirmName = confirmName;
		this.confirmEmail = confirmEmail;
		this.preferlocation = preferlocation;
	}
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getConfirmName() {
		return confirmName;
	}
	public void setConfirmName(String confirmName) {
		this.confirmName = confirmName;
	}
	public String getConfirmEmail() {
		return confirmEmail;
	}
	public void setConfirmEmail(String confirmEmail) {
		this.confirmEmail = confirmEmail;
	}
	public String getPreferlocation() {
		return preferlocation;
	}
	public void setPreferlocation(String preferlocation) {
		this.preferlocation = preferlocation;
	}
	@Override
	public String toString() {
		return "AppliedJob [Id=" + Id + ", confirmName=" + confirmName + ", confirmEmail=" + confirmEmail
				+ ", preferlocation=" + preferlocation + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}



