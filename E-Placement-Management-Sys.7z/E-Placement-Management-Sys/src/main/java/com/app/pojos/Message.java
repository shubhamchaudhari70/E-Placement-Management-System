package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Message {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@Column(length = 255)
	private String tpomsg;
	@Column(length = 255)
	private String companymsg;
	
	public Message() {
		super();
	}
	
	
	
	public Message(Integer id, String tpomsg, String companymsg) {
		super();
		this.id = id;
		this.tpomsg = tpomsg;
		this.companymsg = companymsg;
	}



	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	
	public String getTpomsg() {
		return tpomsg;
	}



	public void setTpomsg(String tpomsg) {
		this.tpomsg = tpomsg;
	}



	public String getCompanymsg() {
		return companymsg;
	}



	public void setCompanymsg(String companymsg) {
		this.companymsg = companymsg;
	}



	@Override
	public String toString() {
		return "Message [id=" + id + ", tpomsg=" + tpomsg + ", companymsg=" + companymsg + "]";
	}



	
	
	
	
	
	
	
	
	
	
}
