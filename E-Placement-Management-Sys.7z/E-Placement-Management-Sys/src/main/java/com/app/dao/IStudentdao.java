package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojos.Student;

public interface IStudentdao extends JpaRepository<Student, Integer> {
	 //search by student name
	Optional<Student> findByName(String sName);  											//if this method is not declare here ,then in Student service jpa will not give this method in intelligence
	public Student findByEmail(String Email);
	public String findByEmailAndPassword(String Email,String Password);	//for login.    ,  ( And ) and should be capital 1st letter
}
