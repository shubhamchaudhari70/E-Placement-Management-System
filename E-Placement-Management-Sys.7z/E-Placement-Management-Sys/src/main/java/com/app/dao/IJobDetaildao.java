package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.JobDetail;


public interface IJobDetaildao extends JpaRepository<JobDetail, Integer> {
	Optional<JobDetail> findByDesignation(String sjob);
	Optional<JobDetail> findBySalary(Double sa);
}
