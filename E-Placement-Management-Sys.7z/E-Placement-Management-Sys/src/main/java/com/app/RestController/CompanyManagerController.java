package com.app.RestController;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.AppliedJob;
import com.app.pojos.CompanyManager;
import com.app.pojos.JobDetail;
import com.app.pojos.Student;

import com.app.services.ICompanyManagerService;
import com.app.services.IJobDetailService;
import com.app.services.IStudentService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController	
@RequestMapping("/company")
public class CompanyManagerController {

	@Autowired
	private ICompanyManagerService service;				//for CompanyManager pojo , login,register,
	@Autowired
	private IStudentService service1;									//for students pojo
	@Autowired
	private IJobDetailService service2;								//for jobDetail pojo ,  addjob, editjob, deljob,
	
	
	
	
	@PostMapping("/login")																													//for login
	public ResponseEntity<?> LoginCompany(@RequestBody CompanyManager cm) {
		System.out.println("in loginCompany" + cm.getName() + " " + cm.getEmail());
		try {
				return new ResponseEntity<String>(service.fetchStudentByEmailAndPassword(cm.getEmail(),cm.getPassword()), HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<String>("Company login failed", HttpStatus.NO_CONTENT);
		}
	}
	
		
	
	@PostMapping("/register")																															//for register
	public ResponseEntity<?> registerCompanyManager(@RequestBody CompanyManager m) {
		System.out.println("in register Company Manager " + m);
		try {
			CompanyManager savedCompanyManager  = service.registerCompany(m);
			return new ResponseEntity<>( savedCompanyManager, HttpStatus.OK);

		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Company Registration failed "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	/*--------------------------------------------------------------job details--------------------------------------------------------------------------------------------------------------------*/	
		
	@PostMapping(path = "/addjob")																			
	public JobDetail addJobDetails(@RequestBody JobDetail jd){		
		System.out.println("in addJobDetails()");
		return service2.addJobDetailsToDB(jd);														//service method call ,also data send to service----->DB-->again in dao-->service-->here hence return type Companies 
		
	}
	
	
	@PutMapping("/editjobbyid/{jobid}")
	public ResponseEntity<?> editJobDetails(@PathVariable int jobid, @RequestBody JobDetail jd) {						//Response entity return actual data to angular
		System.out.println("in editjob details " + jobid + " " + jd);
		try {
			JobDetail editedDetails = service2.editJobtDetailsToDB(jobid, jd);
			return new ResponseEntity<>(editedDetails, HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	@DeleteMapping(path = "/deljobbyid/{id}")												// Deletemapping nd Getmapping are same
	public String delJobById(@PathVariable int id){								//String return type becz we return a message deleted or not
		System.out.println("in delJobById()"+ getClass().getName() );
		return service2.delJobByIdToDB(id);
		
	}
	

	
	
/*--------------------------------------------------------------for student and CompanyManager--------------------------------------------------------------------------------------------------------------------*/	
	
	@GetMapping("/getalljob")
	public ResponseEntity<?> getlistAllJobs(){							//manager can view itself list of all job, also student can see
	  System.out.println("in list all jobs()");
	  List<JobDetail>jobs=service2.getAllStudents();							//when req come from angular then this service method called
	  if(jobs.isEmpty())																			//condition check if no data found in DB 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
	  return new ResponseEntity<>(jobs,HttpStatus.OK);					//else return response entity mde job list
	}
	
	

	
	
	
	
	
	
	
	
	
	/*--------------------------------------------------------------Only for student --------------------------------------------------------------------------------------------------------------------*/	
	
	@GetMapping(path = "/jobdetail/{designName}")														//cin postman [company/jobdetail/develpoer]		//hi method ek tr student mde declare becz student see job by name, naitr angular mde student profile mde yachi link connect karun dene direct
	public ResponseEntity<?>getJobDetails(@PathVariable String designName)
	{
	     System.out.println("in get job Details"+designName);
	     Optional<JobDetail> jobDetails=service2.getJobDetailsFromDB(designName);				//invoke service method
	     if(jobDetails.isPresent())
	    	return new ResponseEntity<>(jobDetails.get(),HttpStatus.OK);				//if data found then return new updated Response entity with status OK
	     return new ResponseEntity<>(HttpStatus.NO_CONTENT);							//else No content and status 404
	     
	}
	
/*--------------------------------------- Company can see whose student apply for whose  job , only view-----------------------------------------------------------------------------------------------------------*/	

	@GetMapping("/appliedstudentlist")
	public ResponseEntity<?> listAllAppliedStudents(){							//list of all students this method will only access by tpo
	  System.out.println("in list all Students()");
	  List<AppliedJob>appliedstudents=service1.getAllAppliedStudentFromDB();							//when req come from angular then this service method called
	  if(appliedstudents.isEmpty())																			//condition check if no data found in DB 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
	  return new ResponseEntity<>(appliedstudents,HttpStatus.OK);					//else return response entity mde students list
	}
	

	
/*--------------------------------------- Company can delete students for shortlisting  -----------------------------------------------------------------------------------------------------------*/	
	
	@DeleteMapping(path = "/delappliedjobbyid/{id}")											//company karel delete			// Deletemapping nd Getmapping are same
	public ResponseEntity<?> delAppliedJobById(@PathVariable int id){								//String return type becz we return a message deleted or not
		System.out.println("in delete " + getClass().getName() );
		try {
			 service1.delAppliedJobById(id);
			return new ResponseEntity<>(HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	
	
	
	
	//getshortlisting student //
	
	
/*--------------------------------------------------------------student--------------------------------------------------------------------------------------------------------------------*/	
		@GetMapping("/viewallstudent")
		public ResponseEntity<?> listAllStudents(){							//list of all students this method will only access by tpo
		  System.out.println("in list all Students()");
		  List<Student>students=service1.getAllStudents();							//when req come from angular then this service method called
		  if(students.isEmpty())																			//condition check if no data found in DB 
			  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
		  return new ResponseEntity<>(students,HttpStatus.OK);					//else return response entity mde students list
		  
		
		
		}
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	
}
