package com.app.RestController;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.AppliedJob;
import com.app.pojos.JobDetail;
import com.app.pojos.Message;
import com.app.pojos.Student;
import com.app.services.IJobDetailService;
import com.app.services.IStudentService;
import com.app.services.ITpoService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController	
@RequestMapping("/student")

public class StudentController {
	
	@Autowired															//Dependency Injection
	private IStudentService service;							//i/f IStudentService
	@Autowired
	private IJobDetailService service1;
	
	@Autowired
	private ITpoService service2;
	
	public StudentController() {
		System.out.println("in ctor of"+getClass().getName());
	}
	
	/*--------------------------------------------------------------------Login validation-------------------------------------------------------------------------------------------------------------------*/	
	
	@PostMapping("/login")
	public ResponseEntity<?> LoginStudent(@RequestBody Student st) {
		System.out.println("in process login form Student" + st.getEmail() + " " + st.getPassword());
		try {
				return new ResponseEntity<String>(service.fetchStudentByEmailAndPassword(st.getEmail(),st.getPassword()) , HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<String>("Student login failed", HttpStatus.NO_CONTENT);
		}
	}

/*------------------------------------------------------------------------Registration---------------------------------------------------------------------------------------------------------------*/	

	@PostMapping("/register")
	public ResponseEntity<?> registerStudent(@RequestBody Student rs){
		System.out.println("in registerStudent " + rs);
			try {
			Student savedStudent=service.registerStudent(rs);
			return new ResponseEntity<>(savedStudent, HttpStatus.OK);
		}
		catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Student Registration failed "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
/*------------------------------------------------------------Only Tpo---------------------------------------------------------------------------------------------------------------------------*/	

	@GetMapping
	public ResponseEntity<?> listAllStudents(){							//list of all students this method will only access by tpo
	  System.out.println("in list all Students()");
	  List<Student>students=service.getAllStudents();							//when req come from angular then this service method called
	  if(students.isEmpty())																			//condition check if no data found in DB 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
	  return new ResponseEntity<>(students,HttpStatus.OK);					//else return response entity mde students list
	}
	
/*----------------------------------------------------------for Tpo and Company-----------------------------------------------------------------------------------------------------------------------------*/	
	
	@GetMapping(path = "/{studentName}")
	public ResponseEntity<?>getStudentDetails(@PathVariable String studentName)
	{
	     System.out.println("in get student Details"+studentName);
	     Optional<Student> studentDetails=service.getStudentDetails(studentName);				//invoke service method
	     if(studentDetails.isPresent())
	    	 return new ResponseEntity<>(studentDetails.get(),HttpStatus.OK);				//if data found then return new updated Response entity with status OK
	     return new ResponseEntity<>(HttpStatus.NO_CONTENT);							//else No content and status 404
	     
	}
	
/*-------------------------------------------------------------for Student only--------------------------------------------------------------------------------------------------------------------------*/	

	// req handling method to update existing student
		@PutMapping("/updatestudentbyid/{studentId}")
		public ResponseEntity<?> updateStudentDetails(@PathVariable int studentId, @RequestBody Student p) {						//Response entity return actual data to angular
			System.out.println("in update " + studentId + " " + p);
			try {
				Student updatedDetails = service.updateStudentDetails(studentId, p);
				return new ResponseEntity<>(updatedDetails, HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
			} catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			}
		}
	
/*-----------------------------------------------------------------Only For Tpo ----------------------------------------------------------------------------------------------------------------------*/	

	
		@DeleteMapping(path = "/delstudentbyid/{id}")												// Deletemapping nd Getmapping are same
		public ResponseEntity<?> delStudentById(@PathVariable int id){								//String return type becz we return a message deleted or not
			System.out.println("in delete " + getClass().getName() );
			try {
				 service.delStudentById(id);
				return new ResponseEntity<>(HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
			} catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}



/*---------------------------------------JoB Details service1  Student can see all the job that set by company-----------------------------------------------------------------------------------------------------------*/	
	
		@GetMapping("/getalljob")
		public ResponseEntity<?> getlistAllJobs(){							//manager can view itself list of all job, also student can see
		  System.out.println("in list all jobs()");
		  List<JobDetail>jobs=service1.getAllStudents();							//when req come from angular then this service method called
		  if(jobs.isEmpty())																			//condition check if no data found in DB 
			  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
		  return new ResponseEntity<>(jobs,HttpStatus.OK);					//else return response entity mde job list
		}
	
	
		
		
		
		
/*--------------------------------------- Student can see all the job and apply, view-----------------------------------------------------------------------------------------------------------*/	
	
		
		@PostMapping("/apply")																						//when student click on apply then one form open take confirmative info then submit, after submitting control come in this 
		public ResponseEntity<?> applyJob(@RequestBody AppliedJob aj){				//code and info save in AppliedJob table
			System.out.println("in applyjob " + aj);
				try {
				AppliedJob savedJob=service.applyJobbyStud(aj);
				return new ResponseEntity<>(savedJob, HttpStatus.OK);
			}
			catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<String>("Student Job Application failed "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
/*--------------------------------------- Only company see the applied job details of student-----------------------------------------------------------------------------------------------------------*/	
	
		@GetMapping("/appliedstudentlist")
		public ResponseEntity<?> listAllAppliedStudents(){							//list of all students this method will only access by tpo
		  System.out.println("in list all Students()");
		  List<AppliedJob>appliedstudents=service.getAllAppliedStudentFromDB();							//when req come from angular then this service method called
		  if(appliedstudents.isEmpty())																			//condition check if no data found in DB 
			  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
		  return new ResponseEntity<>(appliedstudents,HttpStatus.OK);					//else return response entity mde students list
		}
		
		
/*--------------------------------------- Only company delete the applied job details of student for shortlisting-----------------------------------------------------------------------------------------------------------*/	

		@DeleteMapping(path = "/delappliedjobbyid/{id}")											//company karel delete			// Deletemapping nd Getmapping are same
		public ResponseEntity<?> delAppliedJobById(@PathVariable int id){								//String return type becz we return a message deleted or not
			System.out.println("in delete " + getClass().getName() );
			try {
				 service.delAppliedJobById(id);
				return new ResponseEntity<>(HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
			} catch (RuntimeException e) {
				e.printStackTrace();
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
		}
		
		
		
		
		
		
	/*---------------------------------------get message for student from TPO-----------------------------------------------------------------------------------------------------------*/	
	
		
		
		@GetMapping(path = "/getmessagebyname/{tpomsg}")											
		public ResponseEntity<?>fetchMessageByName(@PathVariable String tpomsg)
		{
			System.out.println("in fetchMessageByName()");
		     Optional<Message> msgDetails=service2.fetchMessageByNameFromDB(tpomsg);				//invoke service method
		     if(msgDetails.isPresent())
		    	return new ResponseEntity<>(msgDetails.get(),HttpStatus.OK);				//if data found then return new updated Response entity with status OK
		     return new ResponseEntity<>(HttpStatus.NO_CONTENT);							//else No content and status 404
		     
		}

		
		
		
	
	
	
	
	
	
}
