package com.app.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.AppliedJob;
import com.app.pojos.Companies;
import com.app.pojos.JobDetail;
import com.app.pojos.Message;
import com.app.pojos.Student;
import com.app.pojos.Tpo;
import com.app.services.ICompanyManagerService;
import com.app.services.IStudentService;
import com.app.services.ITpoService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController			// RESTful end point or API end point or API provider
@RequestMapping("/tpo")
public class TpoController {

	@Autowired
	private ITpoService service;
	
	@Autowired
	private IStudentService service2;
	
	@Autowired
	private ICompanyManagerService service3;
	
	
	
	/*--------------------------------------------------------------------Login validation-------------------------------------------------------------------------------------------------------------------*/	

	
	@PostMapping("/login")
	public ResponseEntity<?> LoginTpo(@RequestBody Tpo tp) {
		System.out.println("in process login form Tpo" + tp.getEmail() + " " + tp.getPassword());
		try {
				return new ResponseEntity<String>(service.fetchTpoByEmailAndPassword(tp.getEmail(),tp.getPassword()) , HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<String>("Tpo login failed", HttpStatus.NO_CONTENT);
		}
	}
	
	/*--------------------------------------------------------------------Registration-------------------------------------------------------------------------------------------------------------------*/	

	
	@PostMapping("/register")
	public ResponseEntity<?> registerTpo(@RequestBody Tpo cp){
		System.out.println("in registerTpo " + cp);
			try {
			Tpo savedTpo=service.registerTpo(cp);
			return new ResponseEntity<>(savedTpo, HttpStatus.OK);
		}
		catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Tpo Registration failed "+e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	
	

	
	
				

	
	
/*----------------------------------------------------------Tpo can view,add,delete company list that can be register with college-----------------------------------------------------------------------------------------------------------------------*/	
	@GetMapping(path = "/getcompanylist")	
	@CrossOrigin(origins = "http://localhost:4200")//url mapping	
	public List<Companies> fetchCompanyList(){	
		System.out.println("in fetchCompanyList()");
		List<Companies>companies=new ArrayList<Companies>()	;			//new object created at begin the list is empty
		companies = service.fetchCompanyList();											//service method call
		System.out.println(companies);
		return companies;
	}
	
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	

	@PostMapping(path = "/addcompany")																			//yala url mapping nai lagt fakt get la lagte
	public Companies addCompany(@RequestBody Companies companies){		
		System.out.println("in addCompany()");
		return service.addCompanyToDB(companies);														//service method call ,also data send to service----->DB-->again in dao-->service-->here hence return type Companies 
		
	}
	
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	
	
	
	@GetMapping(path = "/getcompanybyid/{id}")												// /getcompanybyid  = url name,  /{id} = path variable  
	public Companies fetchCompanyById(@PathVariable int id){								//hence we use @pathvariable annotation for id
		System.out.println("in fetchCompanyById()");
		return service.fetchCompanyById(id).get();
		
	}
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/	
	
	@DeleteMapping(path = "/delcompanybyid/{id}")												// Deletemapping nd Getmapping are same
	public String delCompanyById(@PathVariable int id){								//String return type becz we return a message deleted or not
		System.out.println("in delCompanyById()");
		return service.delCompanyById(id);
		
	}
	
	
	
	
/*-------------------------------------------------------------------Tpo can view ,edit, delete, student details--------------------------------------------------------------------------------------------------------------------*/	
	
	
	@GetMapping
	public ResponseEntity<?> listAllStudents(){							//list of all students this method will only access by tpo
	  System.out.println("in list all Students()");
	  List<Student>students=service2.getAllStudents();							//when req come from angular then this service method called
	  if(students.isEmpty())																			//condition check if no data found in DB 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
	  return new ResponseEntity<>(students,HttpStatus.OK);					//else return response entity mde students list
	}
	 
	
	@GetMapping(path = "/{studentName}")
	public ResponseEntity<?>getStudentDetails(@PathVariable String studentName)
	{
	     System.out.println("in get student Details"+studentName);
	     Optional<Student> studentDetails=service2.getStudentDetails(studentName);				//invoke service method
	     if(studentDetails.isPresent())
	    	 return new ResponseEntity<>(studentDetails.get(),HttpStatus.OK);				//if data found then return new updated Response entity with status OK
	     return new ResponseEntity<>(HttpStatus.NO_CONTENT);							//else No content and status 404
	     
	}
	
	
	@PutMapping("/updatestudentbyid/{studentId}")
	public ResponseEntity<?> updateStudentDetails(@PathVariable int studentId, @RequestBody Student p) {						//Response entity return actual data to angular
		System.out.println("in update " + studentId + " " + p);
		try {
			Student updatedDetails = service2.updateStudentDetails(studentId, p);
			return new ResponseEntity<>(updatedDetails, HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping(path = "/delstudentbyid/{id}")												// Deletemapping nd Getmapping are same
	public ResponseEntity<?> delStudentById(@PathVariable int id){								//String return type becz we return a message deleted or not
		System.out.println("in delete " + getClass().getName() );
		try {
			 service2.delStudentById(id);
			return new ResponseEntity<>(HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
/*--------------------------------------- Tpo can see whose student apply for whose  job , only view-----------------------------------------------------------------------------------------------------------*/	
	
	@GetMapping("/appliedstudentlist")
	public ResponseEntity<?> listAllAppliedStudents(){							//list of all students this method will only access by tpo
	  System.out.println("in list all Students()");
	  List<AppliedJob>appliedstudents=service2.getAllAppliedStudentFromDB();							//when req come from angular then this service method called
	  if(appliedstudents.isEmpty())																			//condition check if no data found in DB 
		  return new ResponseEntity<>(HttpStatus.NO_CONTENT);			//then return new response entity and that content (httpstatus nd Nocontent message) 
	  return new ResponseEntity<>(appliedstudents,HttpStatus.OK);					//else return response entity mde students list
	}
	
	
/*--------------------------------------Messege Service Tpo can give message to Student--------------------------------------------------------------------------------------------------------------*/
	
	@PostMapping(path = "/addmessageforstudent")																			//yala url mapping nai lagt fakt get la lagte
	public Message postMessageToStudent(@RequestBody Message msg){		
		System.out.println("in Postmessege()");
		return service.postMessageToDB(msg);														//service method call ,also data send to service----->DB-->again in dao-->service-->here hence return type Companies 
		
	}
	
	
	
	@PutMapping("/editmessageforstudentbbyid/{msgid}")
	public ResponseEntity<?> editMessageDetails(@PathVariable int msgid, @RequestBody Message m) {						//Response entity return actual data to angular
		System.out.println("in editmessageDetails" + msgid + " " + m);
		try {
			Message updatedDetails = service.editMessageDetailsToDB(msgid, m);
			return new ResponseEntity<>(updatedDetails, HttpStatus.OK);							//if no exception then new updated response entity return to angular with status OK
		} catch (RuntimeException e) {
			e.printStackTrace();
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
		
	
	
	@GetMapping(path = "/getmessagebyname/{tpomsg}")											
	public ResponseEntity<?>fetchMessageByName(@PathVariable String tpomsg)
	{
		System.out.println("in fetchMessageByName()");
	     Optional<Message> msgDetails=service.fetchMessageByNameFromDB(tpomsg);				//invoke service method
	     if(msgDetails.isPresent())
	    	return new ResponseEntity<>(msgDetails.get(),HttpStatus.OK);				//if data found then return new updated Response entity with status OK
	     return new ResponseEntity<>(HttpStatus.NO_CONTENT);							//else No content and status 404
	     
	}
	
	
	
	
	
	
	


}
