package com.app.custom_excs;

public class StudentNotFoundException  extends RuntimeException{
	public StudentNotFoundException(String mesg) {
		super(mesg);
	}
}
