package com.app.custom_excs;

public class CompanyNotFoundException  extends RuntimeException{
	public CompanyNotFoundException(String mesg) {
		super(mesg);
	}
}
