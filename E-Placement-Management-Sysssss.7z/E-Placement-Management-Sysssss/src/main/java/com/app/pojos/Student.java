package com.app.pojos;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Student {	
	@Id																										//primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private Integer sid;
	
	@Column(length = 50 )							
	private String name;
	
	@Column(length = 50 )												
	private String email;
	
	@Column(length =50)														
	private String password;
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate dob;
	
	@Column(length = 50)
	private int contact;
	
	@Enumerated(EnumType.STRING)
	@Column(length = 20)							
	private Gender gender;
	
	@Column(length = 50)
	private String address;
	
	@Column(length = 50)
	private String hobbies;
	
	@Column(length = 50)							
	private double degree_per;
	@Enumerated(EnumType.STRING)
	
	@Column(length = 20)									
	private Branch branch;
	
	@Column(length = 50)
	private String project_details;
	
	
	
	
	public Student() {
		super();
	}


	public Student(Integer sid, String name, String came, String email, String password, LocalDate dob, int contact,
			Gender gender, String address, String hobbies, double degree_per, Branch branch, String project_details
		) {
		super();
		this.sid = sid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.dob = dob;
		this.contact = contact;
		this.gender = gender;
		this.address = address;
		this.hobbies = hobbies;
		this.degree_per = degree_per;
		this.branch = branch;
		this.project_details = project_details;
	
	}






	public Integer getSid() {
		return sid;
	}




	public void setSid(Integer sid) {
		this.sid = sid;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public LocalDate getDob() {
		return dob;
	}




	public void setDob(LocalDate dob) {
		this.dob = dob;
	}




	public int getContact() {
		return contact;
	}




	public void setContact(int contact) {
		this.contact = contact;
	}




	public Gender getGender() {
		return gender;
	}




	public void setGender(Gender gender) {
		this.gender = gender;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getHobbies() {
		return hobbies;
	}




	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}




	public double getDegree_per() {
		return degree_per;
	}




	public void setDegree_per(double degree_per) {
		this.degree_per = degree_per;
	}




	public Branch getBranch() {
		return branch;
	}




	public void setBranch(Branch branch) {
		this.branch = branch;
	}




	public String getProject_details() {
		return project_details;
	}




	public void setProject_details(String project_details) {
		this.project_details = project_details;
	}


	
	@Override
	public String toString() {
		return "Student [sid=" + sid + ", name=" + name + ", email=" + email + ", password=" + password + ", dob=" + dob
				+ ", contact=" + contact + ", gender=" + gender + ", address=" + address + ", hobbies=" + hobbies
				+ ", degree_per=" + degree_per + ", branch=" + branch + ", project_details=" + project_details + "]";
	}

	


	


	
	}

	
