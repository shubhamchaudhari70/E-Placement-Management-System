package com.app.pojos;
import java.time.LocalDate;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="jobDetail")
public class JobDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer jobId;
	
	@Column(name="companyId")
	private Integer companyId;
	
	@Column(name="cname")
	private String cname;
	
	@Column(length = 50,name="designation")
	private String designation;
	
	@Column(length = 50,name="responsibility")
	private String responsibility;
	
	@Column(length = 50,name="skill")
	private String skill;
	
	@Column(length = 50,name="Experience")
	private Integer Experience;
	
	@Column(length = 50,name="technology")
	private String technology;
	
	@Column(length = 50,name="salary")
	private double salary;
	
	@Column(length = 50,name="location")
	private String location;
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate beginDate;															//for arrange drive date
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate endDate;																//for closing drive date
	
	public JobDetail() {
		super();
	}
	
	
	

	public JobDetail(Integer jobId, Integer companyId, String cname, String designation, String responsibility,
			String skill, Integer experience, String technology, double salary, String location, LocalDate beginDate,
			LocalDate endDate) {
		super();
		this.jobId = jobId;
		this.companyId = companyId;
		this.cname = cname;
		this.designation = designation;
		this.responsibility = responsibility;
		this.skill = skill;
		Experience = experience;
		this.technology = technology;
		this.salary = salary;
		this.location = location;
		this.beginDate = beginDate;
		this.endDate = endDate;
	}




	public Integer getJobId() {
		return jobId;
	}
	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}
	public Integer getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}
	
	public String getCname() {
		return cname;
	}


	public void setCname(String cname) {
		this.cname = cname;
	}


	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getResponsibility() {
		return responsibility;
	}
	public void setResponsibility(String responsibility) {
		this.responsibility = responsibility;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public Integer getExperience() {
		return Experience;
	}
	public void setExperience(Integer experience) {
		Experience = experience;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	


	public LocalDate getBeginDate() {
		return beginDate;
	}




	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}




	public LocalDate getEndDate() {
		return endDate;
	}




	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}




	@Override
	public String toString() {
		return "JobDetail [jobId=" + jobId + ", companyId=" + companyId + ", cname=" + cname + ", designation="
				+ designation + ", responsibility=" + responsibility + ", skill=" + skill + ", Experience=" + Experience
				+ ", technology=" + technology + ", salary=" + salary + ", location=" + location + ", beginDate="
				+ beginDate + ", endDate=" + endDate + "]";
	}




	
	
	
	

}
