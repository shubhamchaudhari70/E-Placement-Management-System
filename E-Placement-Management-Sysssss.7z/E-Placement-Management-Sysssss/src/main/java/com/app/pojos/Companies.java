package com.app.pojos;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import org.springframework.format.annotation.DateTimeFormat;

@Entity																								//Jpa will create table for Companies
public class Companies {

	@Id																									//primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int id;

	@Column(length = 30,unique = true)
	private String cname;
	
	@Column
	private String criteria;
	
	@Column(length = 30,unique = true)
	private String email;
	
	@Column
	private String contact;
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate beginDate;		//for arrange drive date
	
	@Column
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate endDate;			//for closing drive date
	
	
	
	public Companies() {
		super();
	}
	
	//Parameterized constructor
		public Companies(int id, String cname, String criteria, String email, String contact, LocalDate beginDate, LocalDate endDate) {
		super();
		this.id = id;
		this.cname = cname;
		this.criteria = criteria;
		this.email = email;
		this.contact = contact;
		this.beginDate = beginDate;
		this.endDate = endDate;
	}
	
	//Getter setters
		public int getId() {
			return id;
		}

	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCriteria() {
		return criteria;
	}
	public void setCriteria(String criteria) {
		this.criteria = criteria;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	

	public LocalDate getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "Companies [id=" + id + ", cname=" + cname + ", criteria=" + criteria + ", email=" + email + ", contact="
				+ contact + ", beginDate=" + beginDate + ", endDate=" + endDate + "]";
	}

	
	

	
	
	
	
}
