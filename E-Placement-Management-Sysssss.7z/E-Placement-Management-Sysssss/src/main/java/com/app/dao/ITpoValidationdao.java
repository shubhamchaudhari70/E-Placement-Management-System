package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Tpo;

public interface ITpoValidationdao extends JpaRepository<Tpo, Integer> {
	//for login
	public String findByEmailAndPassword(String nEmail, String nPassword);				//fakt dao mdech capital parameter with 1st letter, and in i/f service, and service parameter must match as pojo  
	
}
