package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Message;

public interface IMessagedao extends JpaRepository<Message, Integer> {
	//student find message by Tpo
	Optional<Message> findByTpomsg(String sMsg);
}

