package com.app.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.app.pojos.Student;

public interface IStudentdao extends JpaRepository<Student, Integer> {
	 //search by student name
	Optional<Student> findByName(String sName);  																						//if this method is not declare here ,then in Student service jpa will not give this method in intelligence
	//Tpo can find student by email
	public Student findByEmail(String Email);
	//for login
	public String findByEmailAndPassword(String Email,String Password);															//  ( And ) and should be capital 1st letter
}
