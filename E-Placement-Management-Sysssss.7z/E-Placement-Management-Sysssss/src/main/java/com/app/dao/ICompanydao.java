package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.CompanyManager;

public interface ICompanydao extends JpaRepository<CompanyManager, Integer> {
	
	//for  login
	public String findByEmailAndPassword(String Email, String Password);			 									//Only dao mdech capital parameter with 1st letter, and in i/f service, and service parameter must match as pojo  


}
