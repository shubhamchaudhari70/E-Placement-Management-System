package com.app.custom_excs;

public class JobNotFoundException  extends RuntimeException{
	public JobNotFoundException(String mesg) {
		super(mesg);
	}
}
