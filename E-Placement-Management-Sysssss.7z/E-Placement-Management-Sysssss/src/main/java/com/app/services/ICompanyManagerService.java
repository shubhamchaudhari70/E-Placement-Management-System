package com.app.services;



import com.app.pojos.CompanyManager;


public interface ICompanyManagerService {
	//for login
	String fetchCompanyByEmailAndPassword(String emaiI, String password);	   	
	//for register
	CompanyManager registerCompany(CompanyManager m);										

}
