package com.app.services;

import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.app.custom_excs.StudentNotFoundException;
import com.app.dao.IAppliedJob;
import com.app.dao.IStudentdao;
import com.app.pojos.AppliedJob;
import com.app.pojos.Student;

@Service
@Transactional
public class StudentService implements IStudentService {
	
	@Autowired																															//Dependency Injected
	private IStudentdao dao;																										//studentController-->IStudentService-->StudentService-->IStudentdao(student POJO)-->DB
	@Autowired
	private IAppliedJob dao1;																										//studentController-->IStudentService-->StudentService-->IAppliedjob(jobdetail POJO)-->DB
	
	
	
/*--------------------------------------------------------------login------------------------------------------------------------------------------------------------------------------------*/
	
	@Override
	public String fetchStudentByEmailAndPassword(String emaiI, String password) {					//for login
	return	dao.findByEmailAndPassword(emaiI, password);
		
	}
	
/*--------------------------------------------------------------register------------------------------------------------------------------------------------------------------------------------*/
	
	
	@Override
	public Student registerStudent(Student s) {																				//for register
																								
			 Student st=new Student();
			 st.setName(s.getName());
			 st.setEmail(s.getEmail());
			 st.setPassword(s.getPassword());
			 
			return dao.save(st);																													//dao i.e IStudentdao extends jpaRepo 
		}
	

/*--------------------------------------------------------------Tpo can view all student------------------------------------------------------------------------------------------------------------------------*/

	@Override
	public List<Student> getAllStudents() {
		System.out.println("dao imple class " + dao.getClass().getName());
		return dao.findAll();
	}
	
/*--------------------------------------------------------------Company Tpo and student can view, add , update------------------------------------------------------------------------------------------------------------------------*/
	

	@Override
	public  Optional<Student> getStudentDetails(String sName) {
				return dao.findByName(sName);
	}

	/*--------------------------------------------------------------Only student can  add ------------------------------------------------------------------------------------------------------------------------*/
	
	@Override
	public Student addStudentDetails(Student transientPOJO) {
				return dao.save(transientPOJO);																			//transientPOJO aslyane direct data save , detached ast tr khali method dili ah tas karav lagl ast
	}
	
	/*--------------------------------------------------------------Only student and Tpo can update ------------------------------------------------------------------------------------------------------------------------*/


	@Override
	public Student updateStudentDetails(int studentId, Student oldDetails) {					//p1--- means--- detachedPOJO
		Optional<Student> checkPresence = dao.findById(studentId);
		if (checkPresence.isPresent()) {
			// checkpresence.get() : PERSISTENT  POJO                											here dirty checking happen,so we change the state of persistent pojo
			// oldDetails: detached POJO : contains the updates sent by student,    				no dirty checking by pojo------>to DB , means row by row checking
			// change state of persistent POJO
			Student updatedDetails = checkPresence.get();					
			updatedDetails.setAddress(oldDetails.getAddress());											//eth oldDetails means detached ah na so detached pojo mde he update hoil sarv data
			updatedDetails.setName(oldDetails.getName());
			updatedDetails.setEmail(oldDetails.getEmail());
			updatedDetails.setPassword(oldDetails.getPassword());
			updatedDetails.setDob(oldDetails.getDob());
			updatedDetails.setContact(oldDetails.getContact());
			updatedDetails.setGender(oldDetails.getGender());
			updatedDetails.setHobbies(oldDetails.getHobbies());
			updatedDetails.setDegree_per(oldDetails.getDegree_per());
			updatedDetails.setProject_details(oldDetails.getProject_details());
			updatedDetails.setBranch(oldDetails.getBranch());
			
			 
			return updatedDetails;
	}
		
				throw new StudentNotFoundException("Invalid Student");										//in case of no student found : throw custom exception

}

	/*--------------------------------------------------------------Only  Tpo can delete------------------------------------------------------------------------------------------------------------------------*/

	@Override
	public Student delStudentById(int id) {
		dao.deleteById(id);																												//dao method mean jpa chi, yala jr id null milala tr illegalargument throw hence we use try catch block, and return string to we know deleted or not 
		return null;
				
	}

	/*--------------------------------------------------------------Only  Tpo can fetch------------------------------------------------------------------------------------------------------------------------*/

	@Override
	public Student fetchCandidateByEmail(String tempEmail) {
			return dao.findByEmail(tempEmail);
	}


	
	
	
	
	
	
	
//for Apply job, delappliedJob, getallAppliedstudent	
	
	
	
/*--------------------------------------------------------------student apply here------------------------------------------------------------------------------------------------------------------------*/
	@Override
	public AppliedJob applyJobbyStud(AppliedJob o) {															//store data in applied job table, and this data we will fetch in companymnager
		AppliedJob n=new AppliedJob();
		n.setConfirmEmail(o.getConfirmEmail());
		n.setConfirmName(o.getConfirmName());
		n.setPreferlocation(o.getPreferlocation());
		n.setConfirmCompany(o.getConfirmCompany());
		return dao1.save(n);																												//dao 1  i.e IAppliedao extends jpaRepo 
	}

	/*--------------------------------------------------------------Only  Company  can delete------------------------------------------------------------------------------------------------------------------------*/

	@Override
	public AppliedJob delAppliedJobById(int id) {
		dao1.deleteById(id);
		return null;
	}

	/*--------------------------------------------------------------company and Tpo fetch application from here------------------------------------------------------------------------------------------------------------------------*/


	@Override
	public List<AppliedJob> getAllAppliedStudentFromDB() {
		System.out.println("dao imple class " + dao.getClass().getName());
		return dao1.findAll();
		
	}
	
}
	
	
	
