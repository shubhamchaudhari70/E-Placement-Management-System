package com.app.services;

import java.util.List;
import java.util.Optional;

import com.app.pojos.Companies;
import com.app.pojos.Message;
import com.app.pojos.Tpo;

public interface ITpoService {
	//get all companies
	List<Companies> fetchCompanyList();
	// add(post) company details by name
	Companies addCompanyToDB(Companies companies);
	// get company details by id
	Optional<Companies> fetchCompanyById(int id);
	// delete company details by id
	String delCompanyById(int id);
	//login
	String fetchTpoByEmailAndPassword(String email, String password);
	//register
	Tpo registerTpo(Tpo c);
	//Tpo can post message
	Message postMessageToDB(Message msg);
	//Tpo and Student fetch message
	Optional<Message> fetchMessageByNameFromDB(String msg);
	//Tpo can edit message
	Message editMessageDetailsToDB(int msgid, Message o);
	
}