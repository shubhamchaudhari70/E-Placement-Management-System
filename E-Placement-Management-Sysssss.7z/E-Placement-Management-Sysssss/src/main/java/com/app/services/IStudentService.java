package com.app.services;

import java.util.List;
import java.util.Optional;
import com.app.pojos.AppliedJob;
import com.app.pojos.Student;

public interface IStudentService {
	
	//get all students
	List<Student>getAllStudents();
	// get students details by name
	Optional<Student> getStudentDetails(String sName);
	//add new student details
	Student addStudentDetails(Student transientPOJO);
	// update existing students details
	Student updateStudentDetails(int studentId, Student detachedPOJO);
	//Tpo can delete student
	Student delStudentById(int id);
	//Tpo can fetchByEmail
	Student fetchCandidateByEmail(String tempEmail);
	//login
	String fetchStudentByEmailAndPassword(String emaiI, String password);				
	//register
	Student registerStudent(Student s);																				
	//Student can apply job
	AppliedJob applyJobbyStud(AppliedJob aj);
	//Company can delete application of student
	AppliedJob delAppliedJobById(int id);
	//company and Tpo can see all aplications
	List<AppliedJob> getAllAppliedStudentFromDB();


}
