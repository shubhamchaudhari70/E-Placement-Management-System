package com.app.services;


import java.util.List;
import java.util.Optional;

import com.app.pojos.JobDetail;


public interface IJobDetailService {

	//Company can add job
	JobDetail addJobDetailsToDB(JobDetail transientPOJO);
	//Company can edit job
	JobDetail editJobtDetailsToDB(int jobid, JobDetail detachedPOJO);
	//Company can Delete job
	String delJobByIdToDB(int id);
	//Student  can see job details according to designation name
	Optional<JobDetail> getJobDetailsFromDB(String jobName);
	//Student and company can see all job details
	List<JobDetail> getAllJobs();
	

}
